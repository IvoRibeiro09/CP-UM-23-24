#include "function.cpp"

void initialize();

void MeanSquaredVelocity_and_Kinetic();

void computeAccelerations_plus_potential();

void clearAmatrix();

double VelocityVerlet(double dt, int iter, FILE *fp);

void initializeVelocities();

double gaussdist();


